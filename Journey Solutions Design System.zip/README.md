# Journey Solutions Design System

## Overview

**Journey Solutions** is a solo indie developer's app-selling website. The brand centers on a personal, story-driven experience — visitors learn about the developer's background ("About Me"), browse a catalog of apps, interact with individual app pages (with instructions + feedback forms), and get in touch directly.

The website is intentionally simple: a single light-colored background, clean typography, personal writing, and minimal imagery. Navigation is unique — pages are listed along the side with round icon buttons and their names visible directly (not hidden in a hamburger menu).

### Pages
- **Main** — landing/home page
- **About Me** — developer's personal story and background
- **Contact Me** — contact form or info
- **List of Apps** — catalog of all apps
- **[App Name]** — individual app pages with description, how-to instructions, and feature request/feedback form

### Sources Provided
- `uploads/31890985_padded_logo Copy.png` — Full lockup logo (spiral mark + "JOURNEY SOLUTIONS" wordmark), dark burgundy background
- `uploads/LogoOnly_540608_Burg.svg` — Logo mark only (spiral swirl), vector SVG

No codebase or Figma links were provided. Design system was built from the logo assets and brand direction notes.

---

## CONTENT FUNDAMENTALS

**Voice & Tone:** Personal, warm, and direct. First-person ("I built this because…"), not corporate. The developer speaks to users as individuals ("you"), not as an audience. Conversational but professional.

**Casing:** Title case for page names and app names. Sentence case for body copy and descriptions. Button labels are short and action-oriented (e.g. "Get in touch", "Learn more", "Send feedback").

**Copy style:**
- Short paragraphs — 2–4 sentences max
- Clear, jargon-free language
- Personal anecdotes welcome (especially in About Me)
- App descriptions lead with the user benefit, not the technical feature

**Emoji:** Not used. Brand is clean and text/icon-driven.

**Vibe:** Approachable indie developer. Earthy warmth. Honest. Not startup-speak. No buzzwords.

**Examples of on-brand copy:**
- "I built this app after struggling to find a simple way to track my daily habits."
- "Have an idea for a new feature? I read every message."
- "Here's everything I've learned along the way."

---

## VISUAL FOUNDATIONS

### Colors
| Role | Value | Notes |
|------|-------|-------|
| Brand Burgundy (dark) | `#540608` | Primary brand dark, logo background |
| Brand Burgundy (mid) | `#782121` | Secondary brand dark, used in logo mark paths |
| Brand Amber | `#EA8724` | Logo wordmark + swirl color; warm CTA accent |
| Background | `#FAF7F2` | Warm off-white / parchment — the "single light background" |
| Surface | `#FFFFFF` | Card and panel surfaces |
| Text Primary | `#1A1008` | Near-black with warm undertone |
| Text Secondary | `#6B5744` | Muted warm brown for secondary copy |
| Border | `#E2D8CC` | Subtle warm gray-beige border |

### Typography
- **Display / Wordmark:** Condensed, bold, all-caps slab or grotesque. Closest Google Font match: **Oswald** (Bold, 700). Flag: original logo uses a custom condensed font — request exact font file from brand owner.
- **Body:** Readable, warm serif or humanist sans. Recommended: **Lora** (serif, 400/600) for body text to reinforce the personal, story-driven feel.
- **Mono:** Not applicable to this product.

### Backgrounds
Single solid warm off-white (`#FAF7F2`) background throughout. No gradients, no textures, no full-bleed images. Clean and readable.

### Spacing & Layout
- Generous white space — comfortable, unhurried feel
- Side navigation with round icon+label buttons (unique pattern; not hamburger)
- Content area is centered with a max-width (~860px)
- Cards for app listings use subtle shadow and rounded corners

### Shadows & Borders
- Cards: `box-shadow: 0 2px 12px rgba(84, 6, 8, 0.08)` — very subtle, warm-tinted
- Borders: `1px solid #E2D8CC` — soft warm border
- Corner radius: `12px` for cards, `8px` for inputs/buttons, `50%` for nav icons

### Animation
- Minimal. Gentle fade-in on page load (`opacity 0.3s ease`).
- Hover states: slight lift (`translateY(-2px)`) + slightly deeper shadow on cards
- Button hover: background shifts slightly darker (burgundy darkens, amber deepens)
- No bounces, no aggressive motion

### Hover / Press States
- Buttons: hover = darken 10%, active = darken 15% + scale(0.98)
- Nav icons: hover = amber fill with burgundy icon, ring outline
- Links: underline on hover, amber color

### Imagery
- Warm color palette — earthy tones, natural light photography
- Minimal imagery overall; product screenshots are the primary visual content
- No AI-generated imagery; prefer authentic personal photos

### Icons
- Line-style icons, stroke weight ~1.5–2px
- No icon font bundled — using Lucide Icons (CDN) as primary icon set
- Round containers for nav icons (filled circle, burgundy bg → amber icon or vice versa)

### Corner Radii
- `4px` — inputs, small chips
- `8px` — buttons, form elements
- `12px` — cards, panels
- `50%` — nav icon circles, avatar

### Cards
- White background
- `border-radius: 12px`
- `box-shadow: 0 2px 12px rgba(84, 6, 8, 0.08)`
- Optional `border: 1px solid #E2D8CC`
- Padding: `24px`

---

## ICONOGRAPHY

**Approach:** Clean, consistent line icons. No bundled icon font — Lucide Icons loaded from CDN.

**CDN:** `https://unpkg.com/lucide@latest/dist/umd/lucide.js`

**Style:** Stroke-based, 24×24 viewBox, 1.5–2px stroke weight. Rounded line caps and joins.

**Nav Icons:** Each page in the side nav gets a round filled circle button (burgundy or amber background) with a white or contrasting Lucide icon inside.

**Usage in HTML:**
```html
<script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
<i data-lucide="home"></i>
<script>lucide.createIcons();</script>
```

**No emoji** used as icons anywhere in the brand.

**Logo assets:**
- `assets/logo-full.png` — Full lockup (for headers, about page)
- `assets/logo-icon.svg` — Mark only (for favicon, small placements)

---

## FILE INDEX

```
README.md                    ← This file; brand overview + guidelines
SKILL.md                     ← Agent skill descriptor
colors_and_type.css          ← CSS custom properties for colors + type
assets/
  logo-full.png              ← Full Journey Solutions logo lockup (PNG)
  logo-icon.svg              ← Logo mark only (SVG spiral)
preview/
  colors-brand.html          ← Brand color swatches
  colors-semantic.html       ← Semantic color roles
  type-scale.html            ← Typography scale specimen
  type-specimens.html        ← Body + display type in use
  spacing-tokens.html        ← Spacing scale tokens
  radii-shadows.html         ← Border radius + shadow system
  buttons.html               ← Button components (all states)
  nav-icons.html             ← Side nav icon buttons
  form-elements.html         ← Inputs, textarea, form
  app-card.html              ← App listing card component
  logo-usage.html            ← Logo display + usage rules
ui_kits/
  website/
    README.md                ← UI kit notes
    index.html               ← Interactive website prototype (all sections defined inline)
```
